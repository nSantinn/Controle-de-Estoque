<?php
 # CLASSES
 include_once('inc/classes.php');
 $objUsuario = new Usuario();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS -->
    <?php include_once('inc/css.php'); ?>
    <!-- /CSS -->
    <title>Usuários</title>
</head>
<body>
<!-- CONTAINER -->
<div class="container">
<!-- MENU -->
<?php include_once('inc/menu.php'); ?>
<!-- MENU -->
    <h1> <i class="fas fa-home"></i> Lista de Usuários </h1>

 <!-- CONTEUDO -->
 <table class="table table-striped">
        <thead>
            <tr>
                <!-- <th>Ações</th> -->
                <th>Foto</th>               
                <th>ID</th>
                <th>Nome</th>               
                <th>Foto</th>               
            </tr>        
        </thead>
        <tbody> 
            <?php 
                $usuarios = $objUsuario->listar();
                foreach ($usuarios as $usuario) {                    
            ?>
            <tr>
                <td>
                    <!-- BTN EXCLUIR -->
                    <button class="btn btn-danger mt-2" 
                                  data-bs-toggle="modal"
                                  data-bs-target="#modalExcluir"
                                  data-identificacao="<?php echo $usuario->nome; ?>"                                  
                                  data-url="usuario-excluir.php?id=<?php echo $usuario->id_usuario; ?>"
                                  >
                                    <i class="fas fa-trash-alt"></i>
                                    Excluir
                                 </button>
                                 <!-- /BTN EXCLUIR -->
                    <!-- /excluir -->
                    <!-- ver -->
                    <a class="btn btn-primary" href="#">
                        <i class="fas fa-eye"></i>
                    </a>
                    <!-- ver -->
                </td>
                <td><?php echo $usuario->id_usuario;?></td>          
                <td><?php echo $usuario->nome; ?></td>                
                <td>
                    <?php 
                        if ($usuario->foto != '') {
                    ?>
                    <img src="imagens/usuarios/<?php echo $usuario->foto;?>" width="200">
                    <?php
                        }
                    ?>
                </td>                
            </tr> 
            <?php 
              } // fecha o foreach
            ?>       
        </tbody>
    </table>
    <!-- CONTEUDO -->
<!-- RODAPE -->
<?php include_once('inc/rodape.php'); ?>
<!-- /RODAPE -->
</div>
<!--/ CONTAINER -->

<!--  MODAL DE EXCLUSÃO -->
<div class="modal fade" id="modalExcluir" tabindex="-1" role="dialog" aria-labelledby="modalExcluirLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      
      <div class="modal-header">
        <h5 class="modal-title" id="modalExcluirLabel">Exclusão</h5>        
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
      </div>              
        
        <div class="modal-body">
          <h2 class="font-weight-bold" id="identificacao"></h2>
              Tem certeza que deseja realizar esta ação?<br> 
              Não será possível desfazê-la posteriormente!
        </div>

        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
            <a class="btn btn-danger" id="linkExcluir" href=""> Confirmar Exclusão </a>
        </div>
   
    </div>
  </div>
</div>    
<!-- /MODAL DE EXCLUSÃO   -->
</body>

<!-- JS -->
<?php include_once('inc/js.php'); ?>
<!-- /JS -->
         
<!-- SCRIPT MODAL DE EXCLUSÃO  -->
<script>
 // No bootstrap5 o uso do  data-bs-toggle é obrigatório
 
 // https://getbootstrap.com/docs/5.0/components/collapse/
 // .. Em ambos os casos, o data-bs-toggle="collapse"é obrigatório.
  $('#modalExcluir').on('show.bs.modal', function (event) {
    let botaoClicado  = $(event.relatedTarget)   
    let identificacao = botaoClicado.data('identificacao')
    let url           = botaoClicado.data('url')    
    $('#identificacao').text(identificacao)
    $('#linkExcluir').attr('href',url)
  }) ;
</script>
<!-- /SCRIPT MODAL DE EXCLUSÃO -->
</html>