
<?php 
# Classes
require_once('inc/classes.php');

// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

?>

<!DOCTYPE html>

<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS -->
    <?php  include_once('inc/css.php'); ?>
    <!-- /CSS -->

    <title>Minha conta</title>
</head>
<body>
    <!--- TITULO--->
<!-- CONTAINER -->
<div class="container">
        <!-- MENU -->
        <?php 
        include_once('inc/menuAdm.php'); 
        // print_r($_SESSION);
        //pegar o id da notícia que está na URL
        $objUsuario = new Usuario();
        // $id_usuario = $_SESSION['id_usuario'];
        $id_usuario = $_GET['id'];
        $usuario = $objUsuario->Mostrar($_GET['id']);

        
        
        ?>
        <!-- /MENU -->
        <!-- CAMPOS OCULTOS -->
        <input type="hidden" name="id_usuario" value="<?php echo $usuario->id_usuario;?>">
        <!-- foto que a noticia possui -->
        <input type="hidden" name="foto_atual" value="<?php echo $usuario->foto;?>">
        <!-- CAMPOS OCULTOS -->      
        <!-- CONTEUDO -->
        <div class="row">
        <div style="text-align: center" class="row">
                <h1 id="tt1">
                <i class="fas fa-address-card" class="text-secondary"></i>
                    Minha Conta 
                </h1>

                <h1 style="text-align: right">
                        <a class="btn btn-outline-success" href="usuarios-cadastrar.php" style="font-size: 17px;">
                            <i class="fas fa-plus-square"></i>
                            Cadastro de Usuario
                        </a>
                    </h1>  
                    <h1 style="text-align: right"> 
                    <a class="btn btn-outline-primary"   href="usuarios-editar.php?id=<?php echo $_SESSION['id_usuario']; ?> "                                    
                                    title="Editar">
                                    <i class="fas fa-edit"></i> 
                                    Editar 
                                 </a>          
                                 </h1>       
                   
                <!-- TABELA DE LEITORES -->   
                <!--  -->
                
                <table class="table table-striped table-hover">
                    <thead>
                        
                    <tr>
                        <th>Foto</th>
                        <th>Nome</th>
                        <th>Email</th>
                    </tr>    

                <!-- LEITORES -->
                            <?php 
                                // $usuarios = $objUsuario->listar($_SESSION['id_usuario']);
                                $usuarios = $objUsuario->listar($_GET['id']);
                                foreach ($usuarios as $usuario) {                    
                           
                           ?> 
                        <tr>
                    <td> <?php echo Helper::fotoDoUsuario($usuario->id_usuario);?> </td>
                    <td> <?php echo $usuario->nome;?> </td>
                    <td> <?php echo $usuario->email;?> </td>
                                </tr>               
            <?php 
              } // fecha o foreach
            ?>       
        </tbody>
    </table>
    <!-- CONTEUDO -->
<!-- RODAPE -->
<?php include_once('inc/rodape.php'); ?>
<!-- /RODAPE -->
</div>
<!--/ CONTAINER -->
</body>

<!-- JS -->
<?php include_once('inc/js.php'); ?>
<!-- /JS -->
         
</html>