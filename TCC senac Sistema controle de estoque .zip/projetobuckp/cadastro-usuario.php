<?php 
# Classes
require_once('inc/classes.php');

if(isset($_POST['btnCadastrar'])){

    $objUsuario = new Usuario();
    $id = $objUsuario->Cadastrar($_POST,$_FILES['foto']);
    header('location:cadastro-usuario.php?'.$id);
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS -->
    <?php  include_once('inc/css.php'); ?>
    <!-- /CSS -->


    <title>Cadastro de Usuário</title>
</head>
<body>
<!-- CONTAINER -->
<div class="container">
 <!-- MENU -->
 <?php include_once('inc/menu.php'); ?>
<!-- /MENU -->
    <!-- CONTEUDO -->
    <div class="row">
        <h1>
            <i class="fas fa-user-plus"></i>
                Cadastro de Usuário                                  
        </h1>    
    
    <form action="?" method="post" enctype="multipart/form-data">
        <!-- CAMPOS OCULTOS -->
        <!-- <input type="hidden" name="id_usuario" value="<?php echo $_SESSION['id_usuario']?>"> -->
        <!-- CAMPOS OCULTOS -->
        <div class="row">

            <div class="col-md-4 form-group">
                <label class="fw-bolder" for="foto">Foto</label>
                <input class="form-control" type="file" name="foto" id="foto">
            </div>

            <div class="col-md-4 form-group">
                <label class="fw-bolder" for="nome">Nome:</label>
                <input class="form-control" type="text" name="nome" id="nome" required>
            </div>
            <div class="col-md-4 form-group">
                <label class="fw-bolder" for="email">E-mail:</label>
                <input class="form-control" type="email" name="email" id="email" required>
            </div>
            <div class="col-md-6 form-group">
                <label class="fw-bolder" for="senha">Senha:</label>
                <input class="form-control" type="password" name="senha" id="senha">
            </div>

            <div class="col-md-6 form-group">
                <label class="fw-bolder" for="confirma_senha">Confirma Senha:*</label>
                <input class="form-control" type="password" name="confirma_senha" id="confirma_senha" required>
                <div id="alerta" class="alert alert-danger" style="display: none;"></div>
            </div>

        </div>
        <div class="col-12 text-end">
        <input class="btn btn-success mt-2 mb-2" type="submit" value="Cadastrar" name="btnCadastrar">    
        </div>

    </form>

    </div>

    <!-- CONTEUDO -->

 <!-- RODAPE -->
 <?php include_once('inc/rodape.php'); ?>
        <!-- /RODAPE -->
    </div>
<!-- /CONTAINER -->    
</body>
<!-- JS -->
<?php include_once('inc/js.php'); ?>

<!-- Scipt Para Confirmar a Senha -->
<script>
   $('#confirma_senha').blur(function (e) { 
       e.preventDefault();
       var senha = $('#senha').val();
       var confirma_senha =$ ('#confirma_senha').val();

       if (senha != confirma_senha) {
            $("#alerta").empty().hide();
            $("#alerta" ).append("Senhas Não São Iguais");
            $("#alerta").show();
            $('#confirma_senha').val('');
            $('#senha').focus();

       } else {
        $("#alerta").empty().hide();
       }
   }); 
</script>

<script language="javascript">
// Aciona a validação do email ao sair do input
$('#email').blur(function(){        
var email = $(this).val();
// Testa a validação
    if(email != '') {
        // alert('OK');
        $("#alertaEmail").empty().hide();
        // verificar se já possui cadastro
        $.ajax({
            url: 'checarEmail.php',
            type:"POST",
            data: {email: email}                  
            }).done(function(resposta){                                           
                // verificar se a resposta está vazia,
                // o que indica que o e-mail não está sendo utilizado                      
                if( !$.isEmptyObject(resposta) ){
                    $("#alertaEmail").empty().hide();
                    $("#alertaEmail" ).append("Este e-mail já está sendo utilizado, informe outro E-mail!");
                    $("#alertaEmail").show();
                    $('#email').val('');
                    $('#email').focus();
                }else{
                    $("#alertaEmail").empty().hide();
                }
            }).fail(function(jqXHR, textStatus ) {
                console.log("Mensagem de erro: " + textStatus);
            });
    }

});
   
</script>
</html>