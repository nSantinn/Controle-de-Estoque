<?php 
# Classes
require_once('inc/classes.php');

//bloco de verificação se usuario logado
$objHelper = new Helper();
$objHelper->logado();
//fim - bloco de verificação se usuario logado

# Estanciar OBJ
# Estanciar OBJ
$objCategoria = new Categoria();
$objFabricante = new Fabricante();
$objFornecedor = new Fornecedor();
$objGarantia = new Garantia();
$objProduto = new Produto();


// verificar se o botão cadastrar foi acionado
if( isset($_POST['btnSalvar'])){
    $objGarantia = new Garantia(); 
    $id = $objGarantia->editar($_POST);
    header('location:garantia.php?'.$id );
}
    $id_garantia = $_GET['id'];
    $garantia = $objGarantia->mostrar($id_garantia);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS -->
    <?php  include_once('inc/css.php'); ?>
    <!-- /CSS -->

    <title>Editar Garantia</title>
</head>
<body>
<h1 style=" font-size: 17px;  font-family:'Courier New', ; "></h1>
                
<!-- CONTAINER -->
    <div class="container">
        <!-- MENU -->
        <?php include_once('inc/menuAdm.php'); ?>
        <!-- /MENU -->
        <!-- CONTEUDO -->
        <div class="row">
                <h1 style="text-align: center">Editar Garantia</h1>
        </div>
        
        <form action="?" method="post" enctype="multipart/form-data">
            <!-- CAMPOS OCULTOS -->
       
        <input type="hidden" name="id_garantia" value="<?php echo $garantia->id_garantia;?>">
        
        
        <!-- CAMPOS OCULTOS -->
        <div class="row" >


        <!-- <div class="col-md-4 form-group">
                <label class="fw-bolder" for="id_garantia">Garantia*</label>
                <input class="form-control" type="text" name="id_garantia" id="id_garantia" value="<?php echo $garantia->id_garantia;?>" readonly >
            </div> -->

            <div class="col-md-4 form-group">
                <label class="fw-bolder" for="prazo">Prazo*</label>
                <select class="form-control" name="prazo" id="prazo" required>
                <?php
                        
                        $garantias = $objGarantia->listar();
                        foreach ($garantias as $garantia1) {                            
                            
                            echo '<option value="'.$garantia1->prazo.'"';
                            
                            if($garantia1->prazo == $garantia->prazo){
                                echo ' selected="selected"';
                            }
                            
                            echo '>';
                                echo $garantia1->prazo;
                            echo '</option>';
                        }
                    ?>
                </select>     
            </div>
            

                <div class="col-md-4 form-group">
                <label class="fw-bolder" for="descricao">Descrição</label>
                <textarea class="form-control" name="descricao" id="descricao" cols="30" rows="1"  required><?php echo $garantia->descricao;?></textarea>           
            </div>

<p></p>

        </div>
        
        <div class="col-12 text-end">
        <input class="btn btn-outline-success" type="submit" value="Salvar" name="btnSalvar">    
        </div>

    </form>

        <!-- /CONTEUDO -->
        <!-- RODAPE -->
        <?php include_once('inc/rodape.php'); ?>
        <!-- /RODAPE -->
    </div>
<!-- /CONTAINER -->    
</body>
<!-- JS -->
<?php include_once('inc/js.php'); ?>
<!-- /JS -->
</html>