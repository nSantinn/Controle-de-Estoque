<?php 
# Classes
require_once('inc/classes.php');

//bloco de verificação se usuario logado
$objHelper = new Helper();
$objHelper->logado();
//fim - bloco de verificação se usuario logado

# Estanciar OBJ
# Estanciar OBJ
$objCategoria = new Categoria();
$objFabricante = new Fabricante();
$objFornecedor = new Fornecedor();
$objGarantia = new Garantia();
$objProduto = new Produto();


// verificar se o botão cadastrar foi acionado
if( isset($_POST['btnSalvar'])){
    $objProduto = new Produto(); 
    $id = $objProduto->editar($_POST,$_FILES['imagem']);
    header('location:produto.php?'.$id );


    // echo print_r('btnSalvar');
}
    $id_produto = $_GET['id'];
    $produto = $objProduto->mostrar($id_produto);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS -->
    <?php  include_once('inc/css.php'); ?>
    <!-- /CSS -->

    <title>Editar Produto</title>
</head>
<body>
<h1 style=" font-size: 17px;
                font-family:'Courier New', ;
                ">
</h1>
                
<!-- CONTAINER -->
    <div class="container">
        <!-- MENU -->
        <?php include_once('inc/menuAdm.php'); ?>
        <!-- /MENU -->
        <!-- CONTEUDO -->
        <div class="row">
                <h1 style="text-align: center">Editar Produto</h1>
        </div>
        
        <form action="?" method="post" enctype="multipart/form-data">
            <!-- CAMPOS OCULTOS -->
        <input type="hidden" name="id_produto" value="<?php echo $produto->id_produto;?>">
        <!-- foto que a noticia possui -->
        <input type="hidden" name="foto_atual" value="<?php echo $produto->imagem;?>">
        <!-- CAMPOS OCULTOS -->
        <div class="row">


        <div class="col-md-4 form-group">
                <label class="fw-bolder" for="nome">Produto*</label>
                <input class="form-control" type="text" name="nome" id="nome" value="<?php echo $produto->nome;?>" >
            </div>


            <div class="col-md-4 form-group">
                <label class="fw-bolder" for="modelo">Marca</label>
                <input class="form-control" type="text" name="modelo" id="modelo" value="<?php echo $produto->modelo;?>" >
            </div>

            <div class="col-md-4 form-group">
                <label class="fw-bolder" for="cor">Cor*</label>
                <input class="form-control" type="text" name="cor" id="cor" value="<?php echo $produto->cor;?>"  >
            </div>


            
            <div class="col-md-4 form-group">
                <label class="fw-bolder" for="unidade_de_medida">Unidade de Medida*</label>
                <input class="form-control" type="text" name="unidade_de_medida" id="unidade_de_medida" value="<?php echo $produto->unidade_de_medida;?>">
        </div>


                    
        <div class="col-md-4 form-group">
                <label class="fw-bolder" for="compatibilidade">Compatibilidade</label>
                <input class="form-control" type="text" name="compatibilidade" id="compatibilidade" 
                value="<?php echo $produto->compatibilidade;?>" >           
            </div>

            <div class="col-md-2 form-group">
                <label class="fw-bolder" for="status">Status</label>
                <select class="form-select" name="status" id="status" value= "<?php echo $produto->status;?>" >
                <option value="ativo" selected>ativo</option>
                <!-- <option value="ativo"></option> -->
                <option value="inativo">inativo</option>
                </select>   
            </div>
            
            

            <div class="col-md-4 form-group">
                <label class="fw-bolder" for="categoria">Categoria*</label>
                <select class="form-select" name="id_categoria" id="id_categoria" >
                
                <?php
                        $categorias = $objCategoria->listar();
                        foreach ($categorias as $categoria) {                            
                            echo '<option value="'.$categoria->id_categoria.'"';

                            if($categoria->id_categoria == $produto->id_categoria){
                                echo ' selected="selected"';
                            }
                            
                            echo '>';
                                echo $categoria->categoria;
                            echo '</option>';
                        }
                    ?>
                </select>  
            </div>




            <div class="col-md-4 form-group">
                <label class="fw-bolder" for="fabricante">Fabricante*</label>
                <select class="form-select" name="id_fabricante" id="id_fabricante" >
              
                <?php
                        $fabricantes = $objFabricante->listar();

                       
                        foreach ($fabricantes as $fabricante) {                            
                            echo '<option value="'.$fabricante->id_fabricante.'"';

                            if($fabricante->id_fabricante == $produto->id_fabricante){
                                echo ' selected="selected"';
                            }
                            
                            echo '>';
                                echo $fabricante->nome;
                            echo '</option>';
                        }
                    ?>
                </select>  
                  </div>


                <div class="col-md-4 form-group">
                    <label class="fw-bolder" for="fornecedor">Fornecedor*</label>
                    <select class="form-select" name="id_fornecedor" id="id_fornecedor" value="<?php echo $produto->id_fornecedor;?>" >
                    
                    <?php
                        $fornecedores = $objFornecedor->listar();
                        foreach ($fornecedores as $fornecedor) {                            
                            echo '<option value="'.$fornecedor->id_fornecedor.'"';
                               
                            if($fornecedor->id_fornecedor == $produto->id_fornecedor){
                                echo ' selected="selected"';
                            }
                            
                            echo '>';
                                echo $fornecedor->razao_social;
                            echo '</option>';
                        }
                    ?>
                    </select>    
                </div>

                <div class="col-md-4 form-group">
                    <label class="fw-bolder" for="id_garantia">GARANTIA*</label>
                    <select class="form-select" name="id_garantia" id="id_garantia" value="<?php echo $produto->id_garantia;?>" >
                   
                    <?php
                        
                        $garantias = $objGarantia->listar();
                        foreach ($garantias as $garantia) {                            
                            echo '<option value="'.$garantia->id_garantia.'"';
                            
                            if($garantia->id_garantia == $produto->id_garantia){
                                echo ' selected="selected"';
                            }
                            
                            echo '>';
                                echo $garantia->prazo;
                            echo '</option>';
                        }
                    ?>
                    </select>

            </div >
                <div  class="mt-2 mb-1 col-md-4 form-group text-center">
                <label class="fw-bolder" for="foto_atual">Foto atual</label><br>

                <img  src="https://t88sad.sitedeteste.com.br/imagens/produtos/<?php echo $produto->imagem;?>"  width="100"   >
            </div>

            <div class="col-md-4 form-group">
                <label class="fw-bolder" for="imagem">Imagem Produto</label>                
                <input class="form-control" type="file" name="imagem" id="imagem">
                
            </div>
            
            

            <div class="col-md-8 form-group">
                <label class="fw-bolder" for="variacao">Descrição</label>
                <textarea class="form-control" name="variacao" id="variacao" cols="30" rows="8"><?php echo $produto->variacao;?></textarea>           
            </div>
    </div>
        
        <div class="col-12 text-end">
        <input class="btn btn-outline-success" type="submit" value="Salvar" name="btnSalvar">    
        </div>

    </form>

        <!-- /CONTEUDO -->
        <!-- RODAPE -->
        <?php include_once('inc/rodape.php'); ?>
        <!-- /RODAPE -->
    </div>
<!-- /CONTAINER -->    
</body>
<!-- JS -->
<?php include_once('inc/js.php'); ?>
<!-- /JS -->
</html>