<?php 
# Classes
require_once('inc/classes.php');

//bloco de verificação se usuario logado
$objHelper = new Helper();
$objHelper->logado();
//fim - bloco de verificação se usuario logado

$objProduto = new Produto();
$objCategoria = new Categoria();

if(isset($_GET['q']) and $_GET['q'] !=''){
    $produtos = $objProduto->pesquisarProduto($_GET['q']);
  
  } else{
    $produtos = $objProduto->listar();
  }
 
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS -->
    <?php  include_once('inc/css.php'); ?>
    <!-- /CSS -->

    <!-- style -->
    <style>
        #tt1{
            font-size: 40px; 
            text-align: center;
            font-family:'Arial'
        }
        #excloi{
            text-align: left;
        }

        #box{
	/*definimos a largura do box*/
	width:400px;
	/* definimos a altura do box */
	height:30px;
	/* definimos a cor de fundo do box */
	background-color:#FFDEAD;
	/* definimos o quão arredondado irá ficar nosso box */
	border-radius: 10px 20px 30px;

    }

    #border{
    border-color: #FFDEAD;
    border-radius: 150px;
    border-style: groove;
    }
    </style>
    <!-- /style -->
    <title> produto</title>
</head>
<body>


<!-- CONTAINER -->
    <div class="container">
        <!-- MENU -->
      
        <?php include_once('inc/menuAdm.php'); ?>
      
        <!-- /MENU -->

        <!-- CONTEUDO -->
        <div class="row">
                <h1 id="tt1">
                <i class="fas fa-box-open" class="text-secondary"></i>
                    Produto
                </h1>
               
                    <h1 style="text-align: left">
                        <a class="btn btn-outline-success" href="produto-cadastro.php" style="font-size: 17px;">
                            <i class="fas fa-plus-square"></i>
                            Novo produto
                        </a>
                    </h1>              
               <!-- barra de pesquisa -->
                    <nav class="navbar navbar-light ">
                        <div class="container-fluid">
                        <p>
                            <form class="d-flex" method="get" action="?"> 
                                <input type="search" class="form-control me-2" class="btn btn-outline-secondary"   
                                placeholder="Procurar Produto..." aria-label="procurar produto..." name="q">
                                <input type="submit" value="Pesquisar" class="btn btn-outline-primary">
                                
                            </form>
                        </div></p>
                        <!-- /barra de pesquisa -->
               
            

                <!-- TABELA DE PRODUTO -->
                <table class="table ">
                    <thead>
                        <tr>
                            <th class="text-center">Produto</th> 
                            <th>Categoria</th>                            
                            <th> Fornecedor</th>
                            <th> Fabricante</th>                     
                            <th>Quantidade</th> 
                            <th>Status</th>  
                            <th> &nbsp; </th>                         
                                                        
                        </tr>
                    </thead>
                    <tbody>
                         <?php
                            foreach ($produtos as $produto) {                               
                            
                        ?>
                        
                        <!-- PRODUTO -->
                        <tr>

                        <td>
                        <img src="imagens/produtos/<?php echo $produto->imagem;?>" class="rounded mx-auto d-block" alt="..."width="150">
                        <div class="text-center"> <?php echo $produto->nome;?> </div>
                        </td> 
                            <td> <?php echo Helper::nomeDaCategoria($produto->id_categoria);?></td>  
                            <td> <?php echo Helper::nomeDoFornecedor($produto->id_fornecedor);?></td>  
                            <td> <?php echo Helper::nomeDoFabricante($produto->id_fabricante);?></td>  
                            <td> <?php echo $produto->quantidade;?></td>
                            <td> <?php echo $produto->status;?></td>  
                      
                            <td class="excloi">
                                <a class="btn btn-outline-primary col-md-12"   href="produto-editar.php?id=<?php echo $produto->id_produto;?>"                                    
                                    title="Editar">
                                    <i class="fas fa-edit"></i> 
                                    Editar 
                                 </a>
        
                                  
                                 
                            </td>

                        </tr>
                        <?php
                            }
                            ?>
                        <!-- /PRODUTO -->
                    </tbody>
                </table>
                <!-- /TABELA -->
        </div>
        <!-- /CONTEUDO -->
        <!-- RODAPE -->
        <?php include_once('inc/rodape.php'); ?>
        <!-- /RODAPE -->
    </div>
<!-- /CONTAINER -->    

<!--  MODAL DE EXCLUSÃO -->
<div class="modal fade" id="modalExcluir" tabindex="-1" role="dialog" aria-labelledby="modalExcluirLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      
      <div class="modal-header">
        <h5 class="modal-title" id="modalExcluirLabel">Exclusão</h5>        
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
      </div>              
        
        <div class="modal-body">
          <h2 class="font-weight-bold" id="identificacao"></h2>
              Tem certeza que deseja realizar esta ação?<br> 
              Não será possível desfazê-la posteriormente!
        </div>

        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
            <a class="btn btn-danger" id="linkExcluir" href=""> Confirmar Exclusão </a>
        </div>
    </div>
  </div>
</div>    
<!-- /MODAL DE EXCLUSÃO   -->

</body>
<!-- JS -->
<?php include_once('inc/js.php'); ?>

<!-- SCRIPT MODAL DE EXCLUSÃO  -->
<script>
 // No bootstrap5 o uso do  data-bs-toggle é obrigatório
 
 // https://getbootstrap.com/docs/5.0/components/collapse/
 // .. Em ambos os casos, o data-bs-toggle="collapse"é obrigatório.
  $('#modalExcluir').on('show.bs.modal', function (event) {
    let botaoClicado  = $(event.relatedTarget)   
    let identificacao = botaoClicado.data('identificacao')
    let url           = botaoClicado.data('url')    
    $('#identificacao').text(identificacao)
    $('#linkExcluir').attr('href',url)
  }) ;
</script>
<!-- /SCRIPT MODAL DE EXCLUSÃO -->
</html>