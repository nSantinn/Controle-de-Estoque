<?php

class Usuario
{
    
    public $pdo;    
    public $salt = 'Sen@c!'; // uma sequencia de caracteres, para ser usada no  momento da criptografica da senha

    public function __construct()
    {
        $this->pdo = Conexao::conexao();                            
    }

    
    /**
     * Cadastra um novo usuário
     *
     * @param array $dados     
     * @return int
     */
    public function cadastrar(array $dados, $foto_enviada = null)
    {
        $sql = $this->pdo->prepare('INSERT INTO usuarios 
                                    (nome,email, senha, foto)
                                    values
                                    (:nome, :email, :senha, :foto)'
                                    );

        //tratar os dados recebidos        
        $nome               = $dados['nome'];
        $email              = strtolower(trim($dados['email']));
        $senha              = crypt($dados['senha'],$this->salt);
        $foto = '';

        if($foto_enviada){
            $nome_da_foto = Helper::sobeArquivo($foto_enviada,'imagens/usuarios/');
            //verificar se o upload deu certo
            if($nome_da_foto){
                   $foto = $nome_da_foto;
            }
        }

        //mesclar os dados com os parametros
        $sql->bindParam(':nome',$nome);
        $sql->bindParam(':email',$email);
        $sql->bindParam(':senha',$senha);     
        $sql->bindParam(':foto',$foto);  
        // executar
        $sql->execute();
        return $this->pdo->lastInsertId();

    }

    /**
     * lista os usuários
     *   
     * @return array
     * 
     */
    public function listar(int $id_usuario = null)
    {
       $sql = $this->pdo->prepare('SELECT * FROM usuarios WHERE id_usuario = :id_usuario ORDER BY nome ');
       $sql->bindParam(':id_usuario', $id_usuario);
       $sql->execute();      
       $dados =  $sql->fetchAll(PDO::FETCH_OBJ);
       return $dados;
    }


   /**
    * retorna os dados do usuário
    *
    * @param integer $id_usuario
    * @return object
    */
    public function Mostrar( $id_usuario)
    {
        $sql = $this->pdo->prepare('SELECT * FROM usuarios 
                                    WHERE id_usuario = :id_usuario');
        $sql->bindParam(':id_usuario',$id_usuario);
        $sql->execute();
        return $sql->fetch(PDO::FETCH_OBJ);
    }


    /**
     * atualiza um determinado produto
     *
     * @param array $dados
     * @param file $imagem
     * @return int id - do produto
     */
    public function editar(array $dados, $foto_atual = null)
    {
        $sql = $this->pdo->prepare("UPDATE usuarios SET
                                    nome = :nome,
                                    email = :email,
                                    senha = :senha,
                                    foto = :foto
                                    WHERE id_usuario = :id_usuario
                                  ");
        // tratar os dados
        $id_usuario         = $dados['id_usuario'];       
        $nome               = $dados['nome'];
        $email              = strtolower(trim($dados['email']));
        $senha              = crypt($dados['senha'],$this->salt);
        $foto               = '';

            // verificar se alguma imagem foi enviada 
            // e realizar o upload da imagem
            // verificar sew o upload deu certo
            if($foto){
                $nome_da_foto = Helper::sobeArquivo($foto_atual,'imagens/usuario/');
                //verificar se o upload deu certo
                if($nome_da_foto){
                    $foto = $nome_da_foto;
                }
                else
                {
                    // manter a foto que já existia na notícia
                    $foto = $dados['foto_atual'];
                }
            }
       //mesclar os dados com os parametros
       $sql->bindParam(':id_usuario',$id_usuario);
       $sql->bindParam(':nome',$nome);
       $sql->bindParam(':email',$email);
       $sql->bindParam(':senha',$senha);     
       $sql->bindParam(':foto',$foto);  

        // excutar o SQL
        $sql->execute();
        return $id_usuario;

    }

    

    /**
     * atualiza o usuário
     *
     * @param array $dados
     * @param file $foto_enviada
     * @return int
     */
    public function Atualizar(array $dados, $foto = null)
    {
        $sql = $this->pdo->prepare("UPDATE usuarios SET
                                    nome = :nome,
                                    email = :email,
                                    senha = :senha,
                                    foto = :foto
                                    WHERE id_usuario = :id_usuario
                                  ");
        // tratar os dados
        $id_usuario         = $dados['id_usuario'];       
        $nome               = $dados['nome'];
        $email              = strtolower(trim($dados['email']));
        $senha              = crypt($dados['senha'],$this->salt);

            // verificar se alguma foto foi enviada 
            // e realizar o upload da foto
            // verificar sew o upload deu certo
            if($foto){
                $nome_da_foto = Helper::sobeArquivo($foto,'imagens/usuarios/');
                //verificar se o upload deu certo
                if($nome_da_foto){
                    $foto = $nome_da_foto;
                }
                else
                {
                    // manter a foto que já existia na notícia
                    $foto = $dados['foto_atual'];
                }
            }
        

        //mesclar os dados com os parametros
        $sql->bindParam(':id_usuario',$id_usuario);
        $sql->bindParam(':nome',$nome);
        $sql->bindParam(':email',$email);
        $sql->bindParam(':senha',$senha);     
        $sql->bindParam(':foto',$foto);  
 
        // executar
        $sql->execute();
        return $dados['id_usuario'];
    }

    /**
     * Excluir usuario
     *
     * @param integer $id_usuario
     * @return void (esse metodo não retorna nada)
     */
    public function excluir(int $id_usuario)
    {
        $sql = $this->pdo->prepare('DELETE FROM usuarios WHERE id_usuario = :id_usuario');
        $sql->bindParam(':id_usuario',$id_usuario);
        $sql->execute();
    }


    /**
     * ===============================
     *  FUNÇÕES DE LOGIN 
     * ===============================
     */

     /**
      * realiza o login no sistema
      *
      * @param string $email
      * @param string $senha
      * @return response
      */
     public function logar(string $email, string $senha)
     {
         $email =  trim(strtolower($email));
         $senha =  crypt($senha,$this->salt);

         $sql = $this->pdo->prepare('SELECT * FROM usuarios 
                                    WHERE 
                                    email = :email  AND senha = :senha');
        $sql->bindParam(':email',$email);
        $sql->bindParam(':senha',$senha);
        $sql->execute();
        @session_start();
        // verificar se a consulta retornou alguma informação
        if($sql->rowCount() == 1)
        {
            $usuario = $sql->fetch(PDO::FETCH_OBJ);
            $_SESSION['nome'] = $usuario->nome;           
            $_SESSION['id_usuario'] = $usuario->id_usuario;
            $_SESSION['logado'] = true;            
            header('location:produto.php');

        }
        else
        {
            session_destroy();
            header('location:index.php?e');
        }

     }

     /**
      * Verifica se um E-mail já esta sendo utilizado
      *
      * @param string $email
      * @return boolean
      */
     public function verificarDuplicidadeDeEmail(string $email)
     {
        $sql = $this->pdo->prepare('SELECT email FROM usuarios WHERE email = :email');
        $sql->bindParam(':email',$email);        
        $sql->execute();

        if ($sql->rowCount() > 0 ){           
            return true;
        } else {           
            return false;
        }
        
     }



}
?>