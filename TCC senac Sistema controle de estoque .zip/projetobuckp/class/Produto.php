<?php

class Produto{
    // Atributos
    public $pdo;
    
    public function __construct()
    {
        $this->pdo = Conexao::conexao();               
    }
    
    /**
     * Pesquisar produto
     * @return array
     */
    public function pesquisarProduto($q){
    	//montar o SELECT ou o SQL
    	$sql = $this->pdo->prepare('SELECT produtos.*  FROM produtos
        INNER JOIN fornecedor ON fornecedor.id_fornecedor = produtos.id_fornecedor 
        INNER JOIN categoria ON categoria.id_categoria = produtos.id_categoria
        INNER JOIN fabricante ON fabricante.id_fabricante = produtos.id_fabricante
        WHERE produtos.nome like :nome_produto
        or fornecedor.razao_social like :razao_social
        or categoria.categoria like :categoria
        or fabricante.nome like :nome_fabricante
        or produtos.status like :status
        or quantidade like :quantidade');

        // mesclas
        $pesquisado = '%'.$q.'%';
        $sql->bindParam(':nome_produto',$pesquisado);
        $sql->bindParam(':razao_social',$pesquisado);
        $sql->bindParam(':categoria',$pesquisado);
        $sql->bindParam(':nome_fabricante',$pesquisado);
        $sql->bindParam(':quantidade',$pesquisado);
        $sql->bindParam(':status',$pesquisado);
    	//executar a consulta
    	$sql->execute();
    	//pegar os dados retornados
    	$dados = $sql->fetchAll(PDO::FETCH_OBJ);
    	return $dados;
   	 }

        /**
     * listar
     * @return array
     */
    public function listar(){
    	//montar o SELECT ou o SQL
    	$sql = $this->pdo->prepare('SELECT * FROM produtos ORDER BY id_produto');

        // $sql = $this->pdo->prepare('SELECT * FROM produtos where status = "ativo" '); <-----   select para buscar apenas ATIVO
       	//executar a consulta
    	$sql->execute();
    	//pegar os dados retornados
    	$dados = $sql->fetchAll(PDO::FETCH_OBJ);
    	return $dados;
    }



    /**
     * cadastrar um novo produto
     *
     * @date 17-06-2021
     * @param Array $dados
     * @param File  $foto_enviada
     * @return int
     * @example $objProduto->cadastrar($_POST,$_FILES['foto']);
     * 
     */
    public function cadastrar(Array $dados,  $foto_enviada = null)
    {
        $sql = $this->pdo->prepare('INSERT INTO produtos 
                ( id_fornecedor, id_fabricante, id_categoria, id_garantia, nome, modelo, quantidade, cor, unidade_de_medida, variacao, compatibilidade, imagem, status)
                values
                ( :id_fornecedor, :id_fabricante, :id_categoria, :id_garantia, :nome, :modelo, :quantidade, :cor, :unidade_de_medida, :variacao, :compatibilidade, :imagem, :status)
                ');
        // TRATAR OS DADOS
        // $id_produto     = $dados['id_produto'];
        $id_fornecedor     = $dados['id_fornecedor'];
        $id_fabricante     = $dados['id_fabricante'];
        $id_categoria      = $dados['id_categoria'];
        $id_garantia       = $dados['id_garantia'];
        $nome              = ucfirst(strtolower(trim($dados['nome'])));;
        $modelo            = $dados['modelo'] ;
        $quantidade        = $dados['quantidade'];
        $cor               = trim($dados['cor']);
        $unidade_de_medida = $dados['unidade_de_medida'];
        $variacao          = $dados['variacao'];
        $compatibilidade   = $dados['compatibilidade'];
        $imagem            = $dados['imagem'];
        $status            = $dados['status'];

        // verificar se alguma foto foi enviada 
        // e realizar o upload da imagem
        // verificar sew o upload deu certo
        if($foto_enviada){
            $nome_da_foto = Helper::sobeArquivo($foto_enviada,'imagens/produtos/');
            //verificar se o upload deu certo
            if($nome_da_foto){
                   $imagem = $nome_da_foto;
            }
        }

        // mesclar os dados

        // $sql->bindParam(':id_produto',$id_produto);
        $sql->bindParam(':id_fornecedor',$id_fornecedor);
        $sql->bindParam(':id_fabricante',$id_fabricante);
        $sql->bindParam(':id_categoria',$id_categoria);
        $sql->bindParam(':id_garantia', $id_garantia);
        $sql->bindParam(':nome',$nome);
        $sql->bindParam(':modelo',$modelo);
        $sql->bindParam(':quantidade',$quantidade);
        $sql->bindParam(':cor',$cor);
        $sql->bindParam(':unidade_de_medida',$unidade_de_medida);
        $sql->bindParam(':variacao',$variacao);
        $sql->bindParam(':compatibilidade',$compatibilidade);
        $sql->bindParam(':imagem',$imagem);
        $sql->bindParam(':status',$status);

        //executar
        $sql->execute();
        return $this->pdo->lastInsertId();
    }

    /**
     * atualiza um determinado produto
     *
     * @param array $dados
     * @param file $imagem
     * @return int id - do produto
     */
    public function editar(array $dados, $imagem = null)
    {

        $sql = $this->pdo->prepare("UPDATE produtos SET
                                    id_fornecedor     = :id_fornecedor,
                                    id_fabricante     = :id_fabricante,
                                    id_categoria      = :id_categoria,
                                    id_garantia       = :id_garantia,
                                    nome              = :nome,
                                    modelo            = :modelo,
                                    cor               = :cor,
                                    unidade_de_medida = :unidade_de_medida,
                                    variacao          = :variacao,
                                    compatibilidade   = :compatibilidade,
                                    status            = :status,
                                    imagem            = :imagem                                 
                                    WHERE id_produto  = :id_produto
                                  ");

        // tratar os dados
        $id_produto         = $dados['id_produto'];
        $id_fornecedor      = $dados['id_fornecedor'];
        $id_fabricante      = $dados['id_fabricante'];
        $id_categoria       = $dados['id_categoria'];
        $id_garantia        = $dados['id_garantia'];
        $nome               = ucfirst(strtolower(trim($dados['nome'])));;
        $modelo             = $dados['modelo'] ;
        $cor                = trim($dados['cor']);
        $unidade_de_medida  = $dados['unidade_de_medida'];
        $variacao           = $dados['variacao'];
        $compatibilidade    = $dados['compatibilidade'];
        $status             = $dados['status'];
          // verificar se alguma imagem foi enviada 
            // e realizar o upload da imagem
            // verificar sew o upload deu certo
            if($imagem){
                $nome_da_imagem = Helper::sobeArquivo($imagem,'imagens/produtos/');
                //verificar se o upload deu certo
                if($nome_da_imagem){
                    $imagem = $nome_da_imagem;
                }
                else
                {
                    // manter a foto que já existia na notícia
                    $imagem = $dados['foto_atual'];
                }
            }
        
        // MESCLAR OS DADOS
        $sql->bindParam(':id_produto',$id_produto);
        $sql->bindParam(':id_fornecedor',$id_fornecedor);
        $sql->bindParam(':id_fabricante',$id_fabricante);
        $sql->bindParam(':id_categoria',$id_categoria);
        $sql->bindParam(':id_garantia', $id_garantia);
        $sql->bindParam(':nome',$nome);
        $sql->bindParam(':modelo',$modelo);
        $sql->bindParam(':cor',$cor);
        $sql->bindParam(':unidade_de_medida',$unidade_de_medida);
        $sql->bindParam(':variacao',$variacao);
        $sql->bindParam(':compatibilidade',$compatibilidade);
        $sql->bindParam(':imagem',$imagem);
        $sql->bindParam(':status',$status);

        // excutar o SQL
        $sql->execute();
        return $id_produto;

    }

     /**
     * mostrar
     * @param int $id_produto
     * @return object
     */
    public function mostrar(int $id_produto){
    	//montar o SELECT ou o SQL
    	$sql = $this->pdo->prepare('SELECT * FROM produtos WHERE id_produto = :id_produto');
        $sql->bindParam(':id_produto', $id_produto);
    	//executar a consulta
    	$sql->execute();
    	//pegar os dados retornados
    	$dados = $sql->fetch(PDO::FETCH_OBJ);
    	return $dados;
    }

      /**
     * Excluir Produto
     *
     * @param integer $id_produto
     * @return void
     */
    public function excluir(int $id_produto)
    {
        $sql = $this->pdo->prepare('DELETE FROM produtos WHERE id_produto = :id_produto');
        $sql->bindParam(':id_produto',$id_produto);
        $sql->execute();
    }
}

?>