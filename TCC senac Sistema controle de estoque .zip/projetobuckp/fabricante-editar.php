<?php 
# Classes
require_once('inc/classes.php');

//bloco de verificação se usuario logado
$objHelper = new Helper();
$objHelper->logado();
//fim - bloco de verificação se usuario logado


# Estanciar OBJ
# Estanciar OBJ
$objCategoria = new Categoria();
$objFabricante = new Fabricante();
$objFornecedor = new Fornecedor();
$objGarantia = new Garantia();
$objProduto = new Produto();


// verificar se o botão cadastrar foi acionado
if( isset($_POST['btnSalvar'])){
    $objFabricante = new Fabricante(); 
    $id = $objFabricante->editar($_POST);
    header('location:fabricante.php?'.$id );
}
    $id_fabricante = $_GET['id'];
    $fabricante = $objFabricante->mostrar($id_fabricante);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS -->
    <?php  include_once('inc/css.php'); ?>
    <!-- /CSS -->

    <title>Editar Fabricante</title>
</head>
<body>

<h1 style=" font-size: 17px; font-family:'Courier New', ; "></h1>
                
<!-- CONTAINER -->
    <div class="container">
        <!-- MENU -->
        <?php include_once('inc/menuAdm.php'); ?>
        <!-- /MENU -->
        <!-- CONTEUDO -->
        <div class="row">
                <h1 style="text-align: center">Editar Fabricante</h1>
        </div>
        
        <form action="?" method="post" enctype="multipart/form-data">
            <!-- CAMPOS OCULTOS -->
       
      
        
        <!-- CAMPOS OCULTOS -->
        <div class="row" >


        <div class="col-md-4 form-group">
                <label class="fw-bolder" for="id_fabricante">Fabricante*</label>
                <input class="form-control" type="text" name="id_fabricante" id="id_fabricante" value="<?php echo $fabricante->id_fabricante;?>" readonly >
            </div>

           
        
            <div class="col-md-6 form-group" >
                <label class="fw-bolder"for="nome">Nome*</label>
                <input class="form-control" type="text" name="nome" id="nome" value="<?php echo $fabricante->nome;?>" required >
            </div>
            

            <div class="col-md-4 form-group">
                <label class="fw-bolder" for="id_garantia">Garantia*</label>
                <input class="form-control" type="text" name="id_garantia" id="id_garantia" value="<?php echo $fabricante->id_garantia;?>" >
            </div>




        </div>
        
        <div class="col-12 text-end">
        <input class="btn btn-outline-success" type="submit" value="Salvar" name="btnSalvar">    
        </div>

    </form>

        <!-- /CONTEUDO -->
        <!-- RODAPE -->
        <?php include_once('inc/rodape.php'); ?>
        <!-- /RODAPE -->
    </div>
<!-- /CONTAINER -->    
</body>
<!-- JS -->
<?php include_once('inc/js.php'); ?>
<!-- /JS -->
</html>