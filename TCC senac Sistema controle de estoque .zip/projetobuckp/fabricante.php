<?php 
# Classes

require_once('inc/classes.php');


//bloco de verificação se usuario logado
$objHelper = new Helper();
$objHelper->logado();
//fim - bloco de verificação se usuario logado

// OBJs
$objFabricante = new Fabricante();
$objGarantia = new Garantia();

// verificar se o formulario de cadastro foi postado
if(isset($_POST['btnCadastrar']))
{
    $id_fabricante = $objFabricante->cadastrar($_POST);
    header('location:fabricante.php?'.$id_fabricante);
} //fecha o if

// verificar se o formulario de atualização foi postado
if(isset($_POST['btnAtualizar']))
{
    $id_fabricante = $objFabricante->editar($_POST);
    header('location:?'.$id_fabricante);
} //fecha o if

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS -->
    <?php  include_once('inc/css.php'); ?>
    <!-- /CSS -->

    <!-- Style -->
    <style>
        #tt1{
            font-size: 40px; 
            text-align: center;
            font-family:'Arial'
        }
        #excloi{
            text-align: left;
        }

        #box{
	/*definimos a largura do box*/
	width:400px;
	/* definimos a altura do box */
	height:30px;
	/* definimos a cor de fundo do box */
	background-color:#FFDEAD;
	/* definimos o quão arredondado irá ficar nosso box */
	border-radius: 10px 20px 30px;

    }

    #border{
    border-color: #FFDEAD;
    border-radius: 150px;
    border-style: groove;
    }
    </style>
    <!-- /Style -->

    <title>Fabricante</title>
    
</head>
<body>
<!-- CONTAINER -->
    <div class="container">
        <!-- MENU -->
        <?php include_once('inc/menuAdm.php'); ?>
        <!-- /MENU -->

        <!-- CONTEUDO -->
        <div class="row" >
                <h1 id="tt1">
               <i class="fas fa-industry"></i>
                Fabricante
                </h1>
         </div>     
              
                 

                   
                
                <?php
                if(isset($_GET['id'])&& $_GET['id'] != ''){

                    $fabricante = $objFabricante->mostrar($_GET['id']);
                ?>
        
                <!-- FORMULARIO EDITAR -->
                <div id="FormEditar">
                    <form action="?" method="post">
                        <div class="row">
                        <!-- CAMPO OCULTO -->
                        <input type="hidden" name="id_fabricante" value="<?php echo $fabricante->id_fabricante?>">
                            <div class="form-group col-md-3">
                                <label for="fabricante">FABRICANTE</label>
                                <input class="form-control" type="text" name="fabricante" id="fabricante" value="<?php echo $fabricante->id_fabricante?>">   
                          </div>
                            <div class="form-group col-md-4">                                
                               <input class="btn btn-success mt-4" type="submit" value="Atualizar" id="btnAtualizar" name="btnAtualizar"> 
                            </div>                            
                        </div>
                    </form>
                    
                </div>  

                
                <!-- /FORMULARIO EDITAR-->
                <?php
                }
                else
                {
                ?>

                <!-- FORMULARIO CADASTRAR -->
                <div id="FormCadastro">
                    <form action="?" method="post">
                        <div class="row">
                            <div class="form-group col-md-4">
                                <label for="nome">Nome</label>
                                <input class="form-control" type="text" name="nome" id="nome">
                            </div> 
                            
                            <div class="form-group col-md-4">
                                <label for="garantia">Garantia</label>
                                <select class="form-select" name="id_garantia" id="id_garantia" required>
                                <?php
                                 $garantias = $objGarantia->listar();
                                 foreach ($garantias as $garantia) {                            
                                echo '<option value="'.$garantia->id_garantia.'">';
                                echo $garantia->prazo;
                                 echo '</option>';
                                 }
                                 ?>
                                 </select>  
                             </div>           

                            <div class="form-group col-md-4">                                
                               <input class="btn btn-outline-success mt-4" type="submit" value="Adicionar" id="btnCadastrar" name="btnCadastrar"> 
                            </div>   
                            
                           
                               
                        </div>

        
                          
                    </form>
                    
                </div>  
                <!-- /FORMULARIO CADASTRAR-->
                
                <!-- Barra de Pesquisar -->
                <!-- <nav class="navbar navbar-light ">
                        <div class="container-fluid">
                        <a class=""></a>
                            <form class="d-flex">
                                <input class="form-control me-2" class="btn btn-outline-secondary"  type="procurar <div class="form-group col-md-4">
                                <label for="prazo">descricao</label>
                                <input class="form-control" type="text" name="prazo" id="prazo">
                                </div>..." placeholder="procurar <div class="form-group col-md-4">
                                <label for="prazo">descricao</label>
                                <input class="form-control" type="text" name="prazo" id="prazo">
                                </div>..." aria-label="procurar <div class="form-group col-md-4">
                                <label for="prazo">descricao</label>
                                <input class="form-control" type="text" name="prazo" id="prazo">
                                </div>...">
                                <button class="btn btn-outline-primary" type="submit">Pesquisar</button>
                            </form>
                        </div> -->
                    <!-- /Barra de Pesquisar -->
           
               
                <?php
                }
                ?>

                <!-- TABELA DE Fabricante -->
                <table class="table">
                    <thead>
                        <tr>
                            <th> </th>
                            <th> Fabricante</th>
                            <th> Garantia</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- FABRICANTE -->
                        <?php
                            $fabricantes = $objFabricante->listar();
                            foreach ($fabricantes as $fabricante) {                               
                                ?>
                        <tr>
                            
                            <td></td>
                            <td> <?php echo $fabricante->nome; ?> </td>
                            <td> <?php echo $fabricante->prazo; ?> Dia(s) </td>
                            <td class="exclui">
                                    <a class="btn btn-outline-primary col-md-5"   href="fabricante-editar.php?id=<?php echo $fabricante->id_fabricante;?>"                                    
                                        title="Editar">
                                        <i class="fas fa-edit"></i> 
                                        Editar 
                                     </a>
                            </td>
                        </tr>
                        <?php
                          } //fecha foreach
                        ?>
                        <!-- /FABRICANTE -->
                    </tbody>
                </table>
                <!-- /TABELA DE FABRICANTE -->
        <!-- /CONTEUDO -->
        <!-- RODAPE -->
        <?php include_once('inc/rodape.php'); ?>
        <!-- /RODAPE -->
    </div>
<!-- /CONTAINER -->

</body>
<!-- JS -->

<?php  include_once('inc/css.php'); ?>
</html>