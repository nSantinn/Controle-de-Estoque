<?php 
# Classes
require_once('inc/classes.php');

# Estanciar OBJ
$objSaida = new Saida();
$objUsuario = new Usuario();

// verificar se o botão cadastrar foi acionado
if( isset($_POST['btnCadastrar'])){
    $objSaida = new Saida();
    $id = $objSaida->CadastrarSaidaDoProduto($_POST);
    header('location: saida.php?' .$id);
}

// //pegar o id da notícia que está na URL
// $id_produto = $_GET['id'];
// $usuario = $objUsuario->mostrar($id_usuario);

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS -->
    <?php  include_once('inc/css.php'); ?>
    <!-- /CSS -->

    <title>Saídas</title>
</head>
<body>
<!-- CONTAINER -->
    <div class="container">
        <!-- MENU -->
        <?php include_once('inc/menuAdm.php'); ?>
        <!-- /MENU -->
        <!-- CONTEUDO -->
        <div class="col-md-12 form-group">
        <div style="text-align: center" class="row">        
        <h1 >Cadastro de Saída</h1>

    
        </div>      
        <br> 
        <form action="?" method="post" enctype="multipart/form-data">
         <!-- CAMPO OCULTO -->
         <!-- <input type="hidden" name="id_usuario" value="<?php echo $usuario->id_usuario?>"> -->
        <!-- /CAMPO OCULTO -->
        <div class="row">

        <div class="col-md-4 form-group">
                <label class="fw-bolder" for="id_produto">Produto*:</label>
                <select class="form-select" name="id_produto" id="id_produto" required>
                    <option value="">Selecione</option>
                    <?php
                        $objProduto = new Produto();
                        $produtos = $objProduto->listar();
                        foreach ($produtos as $produto) {                            
                            echo '<option value="'.$produto->id_produto.'">';
                                echo $produto->nome;
                            echo '</option>';
                        }
                    ?>
                        </select>
            </div> 

            <div class="col-md-4 form-group">
                <label class="fw-bolder" for="id_tipo_saida">Tipo de Saída*:</label>
                <select class="form-select" name="id_tipo_saida" id="id_tipo_saida" required>
                    <option value="">Selecione</option>
                    <!-- PEGAR TODOS OS FORNECEDORES CADASTRADOS -->
                <?php
                        $objSaida = new Saida();
                        $saidas = $objSaida->TipoDeSaida();
                        foreach ($saidas as $saida) {                            
                            echo '<option value="'.$saida->id_tipo_saida.'">';
                                echo $saida->tipo_saida;
                            echo '</option>';
                        }
                    ?>
                </select>
            </div>

            <div class="col-md-2 form-group">
                <label class="fw-bolder" for="quantidade">Quantidade em estoque</label>
                <input class="form-control" type="int" name="quantidade_estoque" id="quantidade_estoque" value="198" readonly>
            </div>
              
            <div class="col-md-2 form-group">
                <label class="fw-bolder" for="quantidade">Quantidade para Saída</label>
                <input class="form-control" type="int" name="quantidade_saida" id="quantidade">
            </div>

            <div class="col-md-4 form-group">
                <label class="fw-bolder" for="nota_fiscal">Nota Fiscal*:</label>
                <input class="form-control" type="text" name="nota_fiscal" id="nota_fiscal" required>
            </div>
            
            <div class="col-md-8 form-group">
                <label class="fw-bolder" for="observacoes">Observações*</label>
                <textarea class="form-control" type="text" name="observacoes" id="observacoes">  </textarea>
            </div> 
            

    </div>
        <br>
        </div>
        <div class="col-12 text-end">
        <input class="btn btn-success mt-4 mb-4" type="submit" value="Cadastrar" name="btnCadastrar">    
        
    </div>

    </form>
        <!-- /CONTEUDO -->
        <!-- RODAPE -->
        <?php include_once('./inc/rodape.php'); ?>
        <!-- /RODAPE -->
    </div>
<!-- /CONTAINER -->    
</body>
<!-- JS -->
<?php include_once('./inc/js.php'); ?>
<!-- /JS -->
</html>