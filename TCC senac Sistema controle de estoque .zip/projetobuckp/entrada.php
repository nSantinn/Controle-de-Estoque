<?php 
# Classes
require_once('inc/classes.php');
 $objEntrada=  new Entrada ();
 $objUsuario=  new Usuario ();

 if(isset($_GET['q']) and $_GET['q'] !=''){
    $entradas = $objEntrada->pesquisarEntrada($_GET['q']);
  
  } else{
    $entradas = $objEntrada->listarEntrada(); 
  }

 //pegar o id da notícia que está na URL
$id_usuario = $_SESSION['id_usuario'];
$usuario = $objUsuario->Mostrar($_SESSION['id_usuario']);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS -->
    <?php  include_once('inc/css.php'); ?>
    <!-- /CSS -->

    <title> Relação de Entrada</title>
</head>
<body>
<!-- CONTAINER -->
    <div class="container">
        <!-- MENU -->
        <?php include_once('inc/menuAdm.php'); ?>
        <!-- /MENU -->
        <!-- CONTEUDO -->
        
        <div style="text-align: center" class="row">
                <h1 id="tt1">
                    Entrada
                </h1>
               
                    <h1 style="text-align: left">
                        <a class="btn btn-outline-success" href="cadastro-entrada.php?<?php echo $usuario->id_usuario?>" style="font-size: 17px;">
                            <i class="fas fa-plus-square"></i>
                            Nova Entrada
                        </a>
                    </h1>   
                    <!-- barra de pesquisa -->
                    <nav class="navbar navbar-light ">
                        <div class="container-fluid">
                        <p>
                            <form class="d-flex" method="get" action="?"> 
                                <input type="search" class="form-control me-2" class="btn btn-outline-secondary"   
                                placeholder="Procurar Produto..." aria-label="procurar produto..." name="q">
                                <input type="submit" value="Pesquisar" class="btn btn-outline-primary">
                                
                            </form>
                        </div></p>
                        <!-- /barra de pesquisa -->           
                <!-- TABELA DE PRODUTOS -->
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Produto</th>
                            <th>Data Entrada</th>
                            <th>Quantidade</th>
                            <th>Código Universal</th>
                            <th>Número de Serie</th>
                            <th>Lote</th>
                            <th>Fornecedor</th>
                            <th>Nota Fiscal</th>
                            <th>Usuario</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- PRODUTOS -->
                        <?php                                                        
                            foreach($entradas as $entrada) {                              
                       ?>
                        <tr>
                            <td><?php echo Helper::nomeDoProduto($entrada->id_produto);?></td>
                            <td><?php echo $entrada->data;?></td>
                            <td><?php echo $entrada->quantidade;?></td>
                            <td><?php echo $entrada->id_produto;?></td>
                            <td><?php echo $entrada->n_serie;?></td>
                            <td><?php echo $entrada->lote;?></td>
                            <td><?php echo $entrada->razao_social;?></td>
                            <td><?php echo $entrada->nota_fiscal;?></td>
                            <td><?php echo Helper::nomeDoUsuario($entrada->id_usuario);?></td>
                            
                            <td> 

                        </tr>
                        <?php
                            }
                        ?>
                        <!-- /PRODUTOS -->
                    </tbody>
                </table>
                <!-- /TABELA DE PRODUTOS -->
        </div>
        <!-- /CONTEUDO -->
        <!-- RODAPE -->
        
      
        <!-- /RODAPE -->
    </div>
<!-- /CONTAINER --> 



</body>
<!-- JS -->

</html>