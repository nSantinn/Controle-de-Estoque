<?php 
# Classes
require_once('inc/classes.php');

# Estanciar OBJ
$objEntrada = new Entrada();

// verificar se o botão cadastrar foi acionado
if( isset($_POST['btnCadastrar'])){
    $objEntrada = new Entrada();
    $id = $objEntrada->CadastrarEntradaDoProduto($_POST);
    header('location:entrada.php?' .$id);
}

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS -->
    <?php  include_once('./inc/css.php'); ?>
    <!-- /CSS -->

    <title>Entradas</title>
</head>
<body>
<!-- CONTAINER -->
    <div class="container">
        <!-- MENU -->
        <?php include_once('inc/menuAdm.php'); ?>
        <!-- /MENU -->
        <!-- CONTEUDO -->
        <div class="col-md-12 form-group">
        <div style="text-align: center" class="row">
        <p> <p>           
        <h1 >Cadastro de Entrada</h1>

    
        </div>      
        <p>
        <br> 
        <form action="?" method="post" enctype="multipart/form-data">
         <!-- CAMPO OCULTO -->
         <input type="hidden" name="id_usuario" value="1">
        <!-- /CAMPO OCULTO -->
        <div class="row">
</p> 
        <div class="col-md-4 form-group">
                <label class="fw-bolder" for="id_produto">Produto*:</label>
                <select class="form-select" name="id_produto" id="id_produto" required>
                    <option value="">Selecione</option>
                    <?php
                        $objProduto = new Produto();
                        $produtos = $objProduto->listar();
                        foreach ($produtos as $produto) {                            
                            echo '<option value="'.$produto->id_produto.'">';
                                echo $produto->nome;
                            echo '</option>';
                        }
                    ?>
                        </select>
            </div>

            <div class="col-md-4 form-group">
                <label class="fw-bolder" for="id_fornecedor">Fornecedor*:</label>
                <select class="form-select" name="id_fornecedor" id="id_fornecedor" required>
                    <option value="">Selecione</option>
                    <!-- PEGAR TODOS OS FORNECEDORES CADASTRADOS -->
                <?php
                        $objFornecedor = new Fornecedor();
                        $fornecedores = $objFornecedor->listar();
                        foreach ($fornecedores as $fornecedor) {                            
                            echo '<option value="'.$fornecedor->id_fornecedor.'">';
                                echo $fornecedor->razao_social;
                            echo '</option>';
                        }
                    ?>
                </select>
            </div>
         
            <div class="center col-md-4 form-group">
                <label class="fw-bolder" for="preco_compra">Preço de compra *</label>
                <input class="form-control" type="text" name="preco_compra" id="preco_compra" required >               
            </div>
            <p>  
            
            <div class="col-md-4 form-group">
                <label class="fw-bolder" for="lote">Lote*:</label>
                <input class="form-control" type="int" name="lote" id="lote" required>
            
            </div>
            
            <div class="col-md-4 form-group">
                <label class="fw-bolder" for="quantidade">Quantidade*</label>
                <input class="form-control" type="int" name="quantidade" id="quantidade" required>
            </div>

            <div class="col-md-4 form-group">
                <label class="fw-bolder" for="nota_fiscal">Nota Fiscal*:</label>
                <input class="form-control" type="int" name="nota_fiscal" id="nota_fiscal" required>
            </div>            
             </p>
    </div>
        <br>
        </div>
        <div class="col-12 text-end">
        <input class="btn btn-success mt-2 mb-2" type="submit" value="Cadastrar" name="btnCadastrar">    
        
    </div>

    </form>
        <!-- /CONTEUDO -->
        <!-- RODAPE -->
        <?php include_once('./inc/rodape.php'); ?>
        <!-- /RODAPE -->
    </div>
<!-- /CONTAINER -->    
</body>
<!-- JS -->
<?php include_once('./inc/js.php'); ?>
<!-- /JS -->
</html>