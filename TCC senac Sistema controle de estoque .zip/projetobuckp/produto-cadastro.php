<?php 
# Classes
require_once('inc/classes.php');


//bloco de verificação se usuario logado
$objHelper = new Helper();
$objHelper->logado();
//fim - bloco de verificação se usuario logado

# Estanciar OBJ
$objCategoria = new Categoria();
$objFabricante = new Fabricante();
$objFornecedor = new Fornecedor();
$objGarantia = new Garantia();

if( isset($_POST['btnCadastrar'])){
    $objProduto = new Produto(); 
    $id = $objProduto->cadastrar($_POST,$_FILES['imagem']);
    header('location:produto.php?'.$id );
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS -->
    <?php  include_once('inc/css.php'); ?>
    <!-- /CSS -->

    <title>Cadastro de Produto</title>
</head>
<body>
<h1 style=" font-size: 17px;
                font-family:'Courier New', ;
                ">
</h1>    
<!-- CONTAINER -->
    <div class="container">
        <!-- MENU -->
        <?php include_once('inc/menuAdm.php'); ?>
        <!-- /MENU -->
        <!-- CONTEUDO -->
        <div class="row">
                <h1 style="text-align: center">Cadastrar Produto</h1>
        </div>
        
        <form action="?" method="post" enctype="multipart/form-data">

        <div class="row">

        <div class="col-md-4 form-group">
                <label class="fw-bolder" for="nome">Produto*</label>
                <input class="form-control" type="text" name="nome" id="nome" required>
            </div>


            <div class="col-md-4 form-group">
                <label class="fw-bolder" for="modelo">Marca</label>
                <input class="form-control" type="text" name="modelo" id="modelo" required>
            </div>

            <div class="col-md-4 form-group">
                <label class="fw-bolder" for="cor">Cor*</label>
                <input class="form-control" type="text" name="cor" id="cor" required >
            </div>


            
            <div class="col-md-4 form-group">
                <label class="fw-bolder" for="unidade_de_medida">Unidade de Medida*</label>
                <input class="form-control" type="text" name="unidade_de_medida" id="unidade_de_medida" required >
        </div>


                    
        <div class="col-md-4 form-group">
                <label class="fw-bolder" for="compatibilidade">Compatibilidade</label>
                <input class="form-control" type="text" name="compatibilidade" id="compatibilidade" 
                 >           
            </div>
            <div class="col-md-2 form-group">
                <label class="fw-bolder" for="status">Status</label>
                <select class="form-select" name="status" id="status" value= "<?php echo $produto->status;?>" required>
                <option value="ativo" selected>ativo</option>
                <!-- <option value="ativo">ativo</option> -->
                <option value="inativo">inativo</option>
            </select>   
            </div>
            
            

            <div class="col-md-4 form-group">
                <label class="fw-bolder" for="categoria">Categoria*</label>
                <select class="form-select" name="id_categoria" id="id_categoria" required>
                <option value="selecione" selected>selecione</option>
                <?php
                        
                        $categorias = $objCategoria->listar();
                        foreach ($categorias as $categoria) {       
                                                 
                            echo '<option value="'.$categoria->id_categoria.'">';
                                echo $categoria->categoria;
                            echo '</option>';
                        }
                    ?>
                </select>  
            </div>




            <div class="col-md-4 form-group">
                <label class="fw-bolder" for="fabricante">Fabricante*</label>
                <select class="form-select" name="id_fabricante" id="id_fabricante" required>
                <option value="selecione" selected>selecione</option>
                <?php
                        $fabricantes = $objFabricante->listar();
                        foreach ($fabricantes as $fabricante) {                            
                            echo '<option value="'.$fabricante->id_fabricante.'">';
                                echo $fabricante->nome;
                            echo '</option>';
                        }
                    ?>
                </select>  
                  </div>


                  <div class="col-md-4 form-group">
                <label class="fw-bolder" for="fornecedor">Fornecedor*</label>
                <select class="form-select" name="id_fornecedor" id="id_fornecedor" required>
                <option value="selecione" selected>selecione</option>
                 <?php
                        $fornecedores = $objFornecedor->listar();
                        foreach ($fornecedores as $fornecedor) {                            
                            echo '<option value="'.$fornecedor->id_fornecedor.'">';
                                echo $fornecedor->razao_social;
                            echo '</option>';
                        }
                    ?>
                </select>    
                  </div>

                  <div class="col-md-4 form-group">
                <label class="fw-bolder" for="id_garantia">GARANTIA*</label>
                <select class="form-select" name="id_garantia" id="id_garantia" required>
                <option value="selecione" selected>selecione</option><?php
                        
                        $garantias = $objGarantia->listar();
                        foreach ($garantias as $garantia) {                            
                            echo '<option value="'.$garantia->id_garantia.'">';
                                echo $garantia->prazo;
                            echo '</option>';
                        }
                    ?>
                </select>  
            </div>

            
                 

            <div class="col-md-4 form-group">
                <label class="fw-bolder" for="imagem">Imagem Produto</label>
                <input class="form-control" type="file" name="imagem" id="imagem"
                ></div>
            

                <div class="col-md-8 form-group">
                <label class="fw-bolder" for="variacao">Descrição</label>
                <textarea class="form-control" name="variacao" id="variacao" cols="30" rows="8" required></textarea>           
            </div>




        </div>
        
        <div class="col-12 text-end">
        <input class="btn btn-outline-success" type="submit" value="Cadastrar" name="btnCadastrar">    
        </div>

    </form>
        <!-- /CONTEUDO -->
        <!-- RODAPE -->
        <?php include_once('inc/rodape.php'); ?>
        <!-- /RODAPE -->
    </div>
<!-- /CONTAINER -->    
</body>
<!-- JS -->
<?php include_once('inc/js.php'); ?>
<!-- /JS -->
</html>