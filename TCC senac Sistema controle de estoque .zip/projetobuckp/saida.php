<?php 
# Classes
require_once('inc/classes.php');
$objSaida =  new Saida();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS -->
    <?php  include_once('inc/css.php'); ?>
    <!-- /CSS -->

    <title> Relação de Saída</title>
</head>
<body>
<!-- CONTAINER -->
    <div class="container">
        <!-- MENU -->
        <?php include_once('inc/menuAdm.php'); ?>
        <!-- /MENU -->
        <!-- CONTEUDO -->
        
        <div style="text-align: center" class="row">      
        
                <h1 id="tt1">
                <i class="fas fa-arrow-circle-up" class="text-secondary"></i>  
                Saída
                </h1>
               
                    <h1 style="text-align: left">
                        <a class="btn btn-outline-success" href="cadastro-saida.php" style="font-size: 17px;">
                            <i class="fas fa-plus-square"></i>
                            Nova Saída
                        </a>
                    </h1>              
               
                    <!-- Barra de Pesquisar -->
                    <nav class="navbar navbar-light ">
                        <div class="container-fluid">
                        <a class=""></a>
                            <form class="d-flex">
                                <input class="form-control me-2" class="btn btn-outline-secondary"  type="procurar produto..." placeholder="procurar produto..." aria-label="procurar produto...">
                                <button class="btn btn-outline-primary" type="submit">Pesquisar</button>
                            </form>
                        </div>


                <!-- TABELA DE PRODUTOS -->
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th> Produto</th>
                            <th> Data Saída</th>
                            <th> Tipo de Saída</th>
                            <th> Quantidade</th>
                            <th> Nota Fiscal</th>
                            <th> Observações</th>
                            <th> Usuario</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- PRODUTOS -->
                        <?php 
                            $saidas = $objSaida->listarSaida();                                                        
                            foreach($saidas as $saida) {                              
                       ?>
                        <tr>
                        
                            <td><?php echo $saida->nomeProd?></td>
                            <td><?php echo $saida->data_saida;?></td>
                            <td><?php echo $saida->tipo_saida;?></td>
                            <td><?php echo $saida->quantidade;?></td>
                            <td><?php echo $saida->nota_fiscal;?></td>
                            <td><?php echo $saida->observacoes;?></td>
                            <td><?php echo $saida->nomeUsu;?></td>
                            
                            <td> 
                              <!-- BTN EXCLUIR -->
                               <!-- <button class="btn btn-danger mt-6"
                                  data-bs-toggle="modal"
                                  data-bs-target="#modalExcluir"
                                  data-identificacao="<?php echo $noticia->titulo; ?>"                                  
                                  data-url="noticia-excluir.php?id=<?php echo $noticia->id_noticia; ?>"
                                  >
                                    <i class="fas fa-trash-alt"></i>
                                    Excluir
                            </button></td> -->
                            <!-- /BTN EXCLUIR -->

                        </tr>
                        <?php
                            }
                        ?>
                        <!-- /PRODUTOS -->
                    </tbody>
                </table>
                <!-- /TABELA DE PRODUTOS -->
        </div>
        <!-- /CONTEUDO -->
        <!-- RODAPE -->
        <?php include_once('inc/rodape.php'); ?>
        <!-- /RODAPE -->
    </div>
<!-- /CONTAINER --> 

<!--  MODAL DE EXCLUSÃO -->
<!-- <div class="modal fade" id="modalExcluir" tabindex="-1" role="dialog" aria-labelledby="modalExcluirLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      
      <div class="modal-header">
        <h5 class="modal-title" id="modalExcluirLabel">Exclusão</h5>        
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
      </div>              
        
        <div class="modal-body">
          <h2 class="font-weight-bold" id="identificacao"></h2>
              Tem certeza que deseja realizar esta ação?<br> 
              Não será possível desfazê-la posteriormente!
        </div>

        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
            <a class="btn btn-danger" id="linkExcluir" href=""> Confirmar Exclusão </a>
        </div>
    -->
    </div>
  </div>
</div>    
<!-- /MODAL DE EXCLUSÃO   -->

</body>
<!-- JS -->
<?php include_once('./inc/js.php'); ?>


<!-- SCRIPT MODAL DE EXCLUSÃO  -->
<script>
 // No bootstrap5 o uso do  data-bs-toggle é obrigatório
 
 // https://getbootstrap.com/docs/5.0/components/collapse/
 // .. Em ambos os casos, o data-bs-toggle="collapse"é obrigatório.
  $('#modalExcluir').on('show.bs.modal', function (event) {
    let botaoClicado  = $(event.relatedTarget)   
    let identificacao = botaoClicado.data('identificacao')
    let url           = botaoClicado.data('url')    
    $('#identificacao').text(identificacao)
    $('#linkExcluir').attr('href',url)
  }) ;
</script>
<!-- /SCRIPT MODAL DE EXCLUSÃO -->
</html>