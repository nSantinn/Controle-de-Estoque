
<!-- <div> <img src="imagens/noticias/logosite.jpg" width="200"> </div> -->

<ul class="nav mt-3 mb-3">
    <li>
        <a class="nav-link" href="index.php"> 
            <i class="fas fa-home"></i>
            Home
        </a>
    </li>
   
    <li>
        <a class="nav-link" href="categoria.php"> 
            <i class="fas fa-align-justify"></i>
            Categorias
        </a>
    </li>
    <li>
        <a class="nav-link" href="cadastro-produto.php"> 
        <i class="fab fa-product-hunt"></i>
           Produto
        </a>
    </li>
    <li>
        <a class="nav-link" href="fornecedor-cadastro.php"> 
        <i class="fas fa-phone-square"></i>
            Fornecedor
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="index.php">
            <i class="fas fa-sign-out-alt"></i>
            Sair
        </a>
    </li>
    
</ul>