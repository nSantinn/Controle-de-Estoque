<?php 
    Helper::logado();
?>
<div class="d-flex flex-row" style="text-align:center">
    <div class="col-md-4 d-flex justify-content-end">
    </div> 
    <div class="col-md-4 d-flex justify-content-center">
        <!-- logo -->
        <a href="entrada.php">
        <img src="imagens\produtos\logo.png"  width="100">
        </a>
        <!-- \logo -->
    </div>     
    <div class="col-md-5 d-flex justify-content-around">
        <ul class="nav mt-5 mb-3">
           
            <li class="nav-item">
            <a class="nav-link" href="minha-conta.php?id=<?php echo $_SESSION['id_usuario']; ?>"> <!-- informar a ação que a class fará e, o endereço que irá ao clicar -->
                    <button type="button" class="btn btn-primary" >            
                    <i class="fas fa-address-card" class="text-secondary"></i> <!-- ícone da classe, escolher um --> 
                    </button>
                                     
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="index.php"> <!-- informar a ação que a class fará e, o endereço que irá ao clicar -->
                    <button type="button" class="btn btn-secondary" >            
                    <i class="fas fa-sign-out-alt" class="text-secondary" ></i> <!-- ícone da classe, escolher um --> 
                    </button>
                                     
                </a>
                </li>

        </ul>
    </div> 
</div>

<div class="d-flex flex-row" style="text-align:center">
    <div class="col-md-12 d-flex justify-content-around">
    <ul class="nav mt-3 mb-3">

<h1 style="font-size: 21px; 
font-family:'Courier New', Courier, monospace, 'Times New Roman', Times, serif"> <!-- dentro do ha definir foratação te texto, fonte, tamanho etc -->
<li class="nav-item">
    
<div class="row col-md">
    <a class="nav-link" href="entrada.php"> <!-- informar a ação que a class fará e, o endereço que irá ao clicar -->
        <button type="button" class="btn btn-primary" >            
        <i class="fas fa-arrow-alt-circle-down" class="text-secondary"></i> <!-- ícone da classe, escolher um --> 
        ENTRADA
        </button>
        </h1>                  
    </a>
</li>

<h2 style="font-size: 21px; 
font-family:'Courier New', Courier, monospace, 'Times New Roman', Times, serif"> <!-- dentro do ha definir foratação te texto, fonte, tamanho etc -->
<li class="nav-item">
<div class="row col-md">
    <a class="nav-link" href="saida.php"> <!-- informar a ação que a class fará e, o endereço que irá ao clicar -->
        <button type="button" class="btn btn-primary" >            
        <i class="fas fa-arrow-circle-up" class="text-secondary"></i> <!-- ícone da classe, escolher um --> 
        
        SAIDA
        </button>
        </h2>                  
    </a>
</li>

<h3 style="font-size: 21px; 
font-family:'Courier New', Courier, monospace, 'Times New Roman', Times, serif"> <!-- dentro do ha definir foratação te texto, fonte, tamanho etc -->
<li class="nav-item">
<div class="row col-md">
    <a class="nav-link" href="produto.php"> <!-- informar a ação que a class fará e, o endereço que irá ao clicar -->
        <button type="button" class="btn btn-primary" >            
        <i class="fas fa-box-open" class="text-secondary"></i> <!-- ícone da classe, escolher um --> 
        
        PRODUTO
        </button>
        </h3>                  
    </a>
</li>

<h1 style="font-size: 21px; 
font-family:'Courier New', Courier, monospace, 'Times New Roman', Times, serif"> <!-- dentro do ha definir foratação te texto, fonte, tamanho etc -->
<li class="nav-item">
    <div class="row col-md">
    <a class="nav-link" href="fornecedor.php"> <!-- informar a ação que a class fará e, o endereço que irá ao clicar -->
        <button type="button" class="btn btn-primary" >            
        <i class="fas fa-user-tie" class="text-secondary"></i> <!-- ícone da classe, escolher um --> 
        
        FORNECEDOR
        </button>
        </h1>                  
    </a>
</li>

<h1 style="font-size: 21px; 
font-family:'Courier New', Courier, monospace, 'Times New Roman', Times, serif"> <!-- dentro do ha definir foratação te texto, fonte, tamanho etc -->
<li class="nav-item">
<div class="row col-md">
    <a class="nav-link" href="categoria.php"> <!-- informar a ação que a class fará e, o endereço que irá ao clicar -->
        <button type="button" class="btn btn-primary" >            
        <i class="fas fa-bookmark" class="text-secondary"></i> <!-- ícone da classe, escolher um --> 
        
        CATEGORIA 
        </button>
        </h1>                  
    </a>
</li>

<h1 style="font-size: 21px; 
font-family:'Courier New', Courier, monospace, 'Times New Roman', Times, serif"> <!-- dentro do ha definir foratação te texto, fonte, tamanho etc -->
<li class="nav-item">
<div class="row col-md">
    <a class="nav-link" href="garantia.php"> <!-- informar a ação que a class fará e, o endereço que irá ao clicar -->
        <button type="button" class="btn btn-primary" >            
        <i class="fas fa-calendar-check" class="text-secondary"></i> <!-- ícone da classe, escolher um --> 
        
        GARANTIA
        </button>
        </h1>                  
    </a>
</li>

<h1 style="font-size: 21px; 
font-family:'Courier New', Courier, monospace, 'Times New Roman', Times, serif"> <!-- dentro do ha definir foratação te texto, fonte, tamanho etc -->
<li class="nav-item">
<div class="row col-md">
    <a class="nav-link" href="fabricante.php"> <!-- informar a ação que a class fará e, o endereço que irá ao clicar -->
        <button type="button" class="btn btn-primary" >            
        <i class="fas fa-industry"></i> <!-- ícone da classe, escolher um --> 
        
        FABRICANTE
        </button>
        </h1>                  
    </a>
</li>







</ul>
    </div>   
</div> 


<hr>