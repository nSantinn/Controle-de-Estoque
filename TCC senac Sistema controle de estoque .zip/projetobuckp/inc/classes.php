<?php
@session_start();
ob_start();
require_once('class/Conexao.php');
require_once('class/Helper.php');
require_once('class/Produto.php');
require_once('class/Categoria.php');
require_once('class/Fornecedor.php');
require_once('class/Fabricante.php');
require_once('class/Garantia.php');
require_once('class/Usuario.php');
require_once('class/Saida.php');
require_once('class/Entrada.php');

?>