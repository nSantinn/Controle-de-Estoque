<?php 
# Classes
require_once('inc/classes.php');

//bloco de verificação se usuario logado
$objHelper = new Helper();
$objHelper->logado();
//fim - bloco de verificação se usuario logado

# Estanciar OBJ
$objCategoria = new Categoria();
$objCategoria = new Categoria();
$objFabricante = new Fabricante();
$objProduto = new Produto(); 
$objGarantia = new Garantia();
$objFornecedor = new Fornecedor(); 

    if(isset($_POST['btnEditar'])){
    $objFornecedor = new Fornecedor(); 
    $fornecedor = $objFornecedor->editar($_POST);
    header('location:fornecedor.php?'.$id );
}
    $id_fornecedor = $_GET['id'];
    $fornecedor = $objFornecedor->mostrar($id_fornecedor);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS -->
    <?php  include_once('inc/css.php'); ?>
    <!-- /CSS -->

    <title>Alterar Fornecedor</title>
</head>
<body>
<h1 style=" font-size: 17px; font-family:'Courier New', ;   "></h1>
<!-- CONTAINER -->
    <div class="container">
      <!-- MENU -->
      <?php include_once('inc/menuAdm.php'); ?>
        <!-- /MENU -->
        <!-- CONTEUDO -->
        <div class="row">
                <h1 style="text-align: center">Editar Fornecedor</h1>
        </div>
        
        <form action="?" method="post" enctype="multipart/form-data">
         <!-- CAMPO OCULTO -->
         <input type="hidden" name="id_fornecedor" value="<?php echo $fornecedor->id_fornecedor;?>">
        <!-- /CAMPO OCULTO -->
        <div class="row">

            <div class="col-md-4 form-group">
                <label class="fw-bolder" for="nome_de_contato">Nome do Contato*</label>
                <input class="form-control" type="text" name="nome_de_contato" id="nome_de_contato" value="<?php echo $fornecedor->nome_de_contato;?>"required>
            </div>

            
            
            <div class="col-md-4 form-group">
                <label class="fw-bolder" for="cnpj">CNPJ*</label>
                <input class="form-control" type="text" name="cnpj" id="cnpj" required placeholder=" XX.XXX.XXX/0001-XX" value="<?php echo $fornecedor->cnpj;?>">
            </div>
            
            <div class="col-md-4 form-group">
                <label class="fw-bolder" for="razao_social">Razão Social*</label>
                <input class="form-control" type="text" name="razao_social" id="razao_social" value="<?php echo $fornecedor->razao_social;?>" required>
            </div>
            
            <div class="col-md-2 form-group">
                <label class="fw-bolder" for="cargo">Cargo Obtido*</label>
                <input class="form-control" type="text" name="cargo" id="cargo" value="<?php echo $fornecedor->cargo;?>" required>
                       
                <!-- <label class="input-group-text fw-bolder" for="inputGroupSelect01" class="fw-bolder">Cargos</label>
                            <select class="form-select" id="inputGroupSelect01">
                                <option selected></option>
                                <option value="1°">Supervisor</option>
                                <option value="2°">Gerente</option>
                                <option value="3°">Funcionario</option>
                                <option value="4°">Outro Cargo....</option>
                            </select> -->
            </div>

           
            
            <div class="col-md-5 form-group">
                <label class="fw-bolder" for="email">Email*</label>
                <input class="form-control" type="email" name="email" id="email" required placeholder="name@example.com" value="<?php echo $fornecedor->email;?>">
            </div>

            
            <div class="col-md-1 form-group">
                <label class="fw-bolder" for="ddd">DDD*</label>
                <input class="form-control" type="text" name="ddd" id="ddd"  placeholder="(XX)" value="<?php echo $fornecedor->ddd;?>" >
            </div>

            <div class="col-md-4 form-group">
                <label class="fw-bolder" for="telefone">Telefone*</label>
                <input class="form-control" type="text" name="telefone" id="telefone"  placeholder="1234-5678" value="<?php echo $fornecedor->telefone;?>" >
            </div>
       

            
            <div class="col-md- form-group">
                <label class="fw-bolder" for="observacoes">Observação*</label>           
                <textarea class="form-control" name="observacoes" id="observacoes" cols="0" rows=""  required><?php echo $fornecedor->observacoes;?></textarea>
            </div>


            
            <div class="col-md-6 form-group">
                <label class="fw-bolder" for="cep">CEP*</label>
                <input class="form-control" type="text" name="cep" id="cep" value="<?php echo $fornecedor->cep;?>" >
            </div>

            
            <div class="col-md-6 form-group">
                <label class="fw-bolder" for="endereco">Endereço*</label>
                <input class="form-control" type="text" name="endereco" id="endereco" value="<?php echo $fornecedor->endereco;?>" >
            </div>

            
            <div class="col-md-6 form-group">
                <label class="fw-bolder" for="numero">Numero*</label>
                <input class="form-control" type="text" name="numero" id="numero" value="<?php echo $fornecedor->numero;?>" >
            </div>


            
            <div class="col-md-6 form-group">
                <label class="fw-bolder" for="bairro">Bairro*</label>
                <input class="form-control" type="text" name="bairro" id="bairro" value="<?php echo $fornecedor->bairro;?>" >
            </div>
            
            
            <div class="col-md-6 form-group">
                <label class="fw-bolder" for="estado">Estado*</label>
                <input class="form-control" type="text" name="estado" id="estado" value="<?php echo $fornecedor->estado;?>" >
            </div>

            
            <div class="col-md-6 form-group">
                <label class="fw-bolder" for="cidade">Cidade*</label>
                <input class="form-control" type="text" name="cidade" id="cidade"value="<?php echo $fornecedor->cidade;?>" >
            </div>
           



        <div class="col-12 text-end">
        <h1 style="text-align: rigth">
        <input    class="btn btn-outline-success"  type="submit" value="Editar" name="btnEditar">    
        </div></h1> 

    </form>
    </h1>
        <!-- /CONTEUDO -->
        <!-- RODAPE -->
        <?php include_once('inc/rodape.php'); ?>
        <!-- /RODAPE -->
    </div>
<!-- /CONTAINER -->    
</body>
<!-- JS -->
<?php include_once('inc/js.php'); ?>
<!-- /JS -->
</html>