<?php 
# Classes
require_once('inc/classes.php');

//bloco de verificação se usuario logado
$objHelper = new Helper();
$objHelper->logado();
//fim - bloco de verificação se usuario logado

// OBJs
$objGarantia = new Garantia();

// verificar se o formulario de cadastro foi postado
if(isset($_POST['btnCadastrar']))
{
    $id_garantia = $objGarantia->cadastrar($_POST);
    header('location:?'.$id_garantia);
} //fecha o if

// verificar se o formulario de atualização foi postado
if(isset($_POST['btnAtualizar']))
{
    $id_garantia = $objGarantia->editar($_POST);
    header('location:?'.$id_garantia);
} //fecha o if

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS -->
    <?php  include_once('inc/css.php'); ?>
    <!-- /CSS -->

    <!-- Style -->
    <style>
        #tt1{
            font-size: 40px; 
            text-align: center;
            font-family:'Arial'
        }
        #excloi{
            text-align: left;
        }

        #box{
	/*definimos a largura do box*/
	width:400px;
	/* definimos a altura do box */
	height:30px;
	/* definimos a cor de fundo do box */
	background-color:#FFDEAD;
	/* definimos o quão arredondado irá ficar nosso box */
	border-radius: 10px 20px 30px;

    }

    #border{
    border-color: #FFDEAD;
    border-radius: 150px;
    border-style: groove;
    }
    </style>
    <!-- /Style -->

    <title>Garantia</title>
    
</head>
<body>
<!-- CONTAINER -->
    <div class="container">
        <!-- MENU -->
        <?php include_once('inc/menuAdm.php'); ?>
        <!-- /MENU -->

        <!-- CONTEUDO -->
        <div class="row" >
                <h1 id="tt1">
                <i class="fas fa-calendar-check" class="text-secondary"></i>
                Garantia
                </h1>
         </div>     
              
                 

                   
                
                <?php
                if(isset($_GET['id'])&& $_GET['id'] != ''){

                    $garantia = $objGarantia->mostrar($_GET['id']);
                ?>
        
                <!-- FORMULARIO EDITAR -->
                <div id="FormEditar">
                    <form action="?" method="post">
                        <div class="row">
                        <!-- CAMPO OCULTO -->
                        <input type="hidden" name="id_garantia" value="<?php echo $garantia->id_garantia?>">
                            <div class="form-group col-md-3">
                                <label for="garantia">GARANTIA</label>
                                <input class="form-control" type="text" name="garantia" id="garantia" value="<?php echo $garantia->id_garantia?>">   
                          
                            </div>
                            <div class="form-group col-md-4">                                
                               <input class="btn btn-success mt-4" type="submit" value="Atualizar" id="btnAtualizar" name="btnAtualizar"> 
                            </div>                            
                        </div>
                    </form>
                    
                </div>  

                
                <!-- /FORMULARIO EDITAR-->
                <?php
                }
                else
                {
                ?>

                                <!-- FORMULARIO CADASTRAR -->
                <div id="FormCadastro">
                    <form action="?" method="post">
                        <div class="row">
                            <div class="form-group col-md-4">
                                <label for="prazo">Prazo</label>
                                <input class="form-control" type="text" name="prazo" id="prazo"> 
                            </div>  
                            
                            <div class="form-group col-md-4">
                                <label for="descricao">Descrição</label>
                                <input class="form-control" type="text" name="descricao" id="descricao">
                            </div>
                            
                            <div class="form-group col-md-4">                                
                               <input class="btn btn-outline-success mt-4" type="submit" value="Adicionar" id="btnCadastrar" name="btnCadastrar"> 
                            </div>   
                                     
                </div>
    
                    </form> 
                
                <!-- /FORMULARIO CADASTRAR-->
                <br>
                <!-- Barra de Pesquisar -->
                <nav class="navbar navbar-light ">
                        <div class="container-fluid">
                        <a class=""></a>
                            <form class="d-flex">
                                <input class="form-control me-2" class="btn btn-outline-secondary"  type="procurar garantia..." placeholder="procurar garantia..." aria-label="procurar garantia...">
                                <button class="btn btn-outline-primary" type="submit">Pesquisar</button>
                            </form>
                        </div>
                    <!-- /Barra de Pesquisar -->
           
               
                <?php
                }
                ?>

                <!-- TABELA DE Garantia -->
                <table class="table ">
                    <thead>
                        <tr>
                            <th> </th>
                            <th> Prazo</th>
                            <th> Descrição</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- GARANTIA -->
                        <?php
                            $garantias = $objGarantia->listar();
                            foreach ($garantias as $garantia) {                               
                                ?>
                        <tr>
                            
                            <td></td>

                            <td> <?php echo $garantia->prazo; ?> Dia(s) </td>
                            <td> <?php echo $garantia->descricao; ?> </td>
                            
                            <td class="exclui">
                                    <a class="btn btn-outline-primary col-md-5"   href="garantia-editar.php?id=<?php echo $garantia->id_garantia;?>"                                    
                                        title="Editar">
                                        <i class="fas fa-edit"></i> 
                                        Editar 
                                     </a>
                            </td>
                        </tr>
                        <?php
                          } //fecha foreach
                        ?>
                        <!-- /GARANTIA -->
                    </tbody>
                </table>
                <!-- /TABELA DE GARANTIA -->
        </div>
        <!-- /CONTEUDO -->
        <!-- RODAPE -->
        <?php include_once('inc/rodape.php'); ?>
        <!-- /RODAPE -->
    </div>
<!-- /CONTAINER -->

</body>
<!-- JS -->
<?php  include_once('inc/css.php'); ?>
</html>