<?php 
# Classes
require_once('inc/classes.php');


$Usuario = new Usuario();

if (isset($_POST['btnLogar'])) {
    $Usuario->Logar($_POST['email'],$_POST['senha']);
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>

<style type="text/css">

#box{
	/*definimos a largura do box*/
	width:400px;
	/* definimos a altura do box */
	height:30px;
	/* definimos a cor de fundo do box */
	background-color:#FFDEAD;
	/* definimos o quão arredondado irá ficar nosso box */
	border-radius: 10px 20px 30px;
}

#left{
  text-align: left;
}

#border{
    border-color: #FFDEAD;
    border-radius: 50px;
    border-style: groove;
}

#btnLogar{
    color: white;
}



form{
    background-color: rgba(255, 255, 255, 0.7);
}


</style>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS -->
    <?php  include_once('inc/css.php'); ?>
    <!-- /CSS -->

    <title>Login</title>
</head>
<body> 
<!-- CONTAINER -->
<h1 style="font-family:'Courier New', Courier, monospace, 'Times New Roman', Times, serif">
    <div class="container">

        <!-- CONTEUDO -->
        <div class="row">
        
        
        <div class="col-md-4"></div> 
       
        <form action="?" method="post" class="mt-5 col-md-4" id="border"> 
        <h2 class="text-center mt-3" style="text-shadow:1px 1px 3px #000">LOGIN</h2>
            <div class="col-md-12" style="text-align: center">
                <img src="https://imgur.com/tWWxhLD.png"  width="160">
            </div>  

            <div class="form-row mt-2">
                <label class="fw-bold" for="email" style="font-size: 20px">E-mail</label>
                <input class="form-control" id="box" type="text" name="email" id="email" required>
            </div>

            <div class="form-row mt-2">
                <label class="fw-bold" for="senha" style="font-size: 20px">Senha</label>
                <input class="form-control" id="box" type="password" name="senha" id="senha">
            </div>    
            
            
            <div class="form-row mt-4 mb-3 text-end">
                <h3 style="text-align: center">
                    <input class="btn btn-sm" style="background-color:#1E90FF" type="submit" value="Realizar Login" id="btnLogar" name="btnLogar">
                    <a style="font-size: 12px" href="autores-cadastro.php">esqueceu sua senha?</a>
                </h3> 
            </div>
            
            <?php if(isset($_GET['e'])) {
                   echo '<div class="alert alert-danger" role="alert"> Usuario ou Senha Invalido </div>';
                }
            ?>
            <?php 
                   if(isset($_GET['ok'])) { 
                   echo '<div class="alert alert-success" role="alert"> Fechado Com Sucesso </div>';
            }
            ?> 

        </form>  
        </div>
        <!-- /CONTEUDO -->
    </div>
<!-- /CONTAINER -->    
</body>
<!-- JS -->
<?php include_once('inc/js.php'); ?>
<!-- /JS -->
</html>